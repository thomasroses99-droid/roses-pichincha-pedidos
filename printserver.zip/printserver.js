// ── Servidor de impresión local para Roses Burgers ────────────────
// Ejecutar con: node printserver.js
// Requiere Node.js instalado en la PC del local

const http = require("http");
const net  = require("net");
const fs   = require("fs");
const os   = require("os");
const path = require("path");
const { exec } = require("child_process");

const PORT = 3001;

function printToIP(ip, buffer) {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let done = false;

    const finish = (err) => {
      if (done) return;
      done = true;
      if (err) reject(err); else resolve();
    };

    const timer = setTimeout(() => {
      socket.destroy();
      finish(new Error(`Tiempo de espera agotado conectando a ${ip}:9100`));
    }, 8000);

    socket.connect(9100, ip, () => {
      console.log(`[DEBUG] Conectado a ${ip}:9100 — enviando ${buffer.length} bytes`);
      socket.write(buffer, () => {
        clearTimeout(timer);
        socket.end(); // cierre gracioso: espera que la impresora reciba todo
      });
    });

    socket.on("close", () => finish(null));

    socket.on("error", (err) => {
      clearTimeout(timer);
      finish(err);
    });
  });
}

function printToWindows(name, buffer) {
  return new Promise((resolve, reject) => {
    const tmp = path.join(os.tmpdir(), `print_${Date.now()}.prn`);
    fs.writeFile(tmp, buffer, (err) => {
      if (err) return reject(err);
      // Intenta primero con nombre directo, luego con ruta de dispositivo
      exec(`copy /B "${tmp}" "${name}"`, (err2) => {
        if (!err2) {
          fs.unlink(tmp, () => {});
          return resolve();
        }
        exec(`copy /B "${tmp}" "\\\\.\\${name}"`, (err3) => {
          fs.unlink(tmp, () => {});
          if (err3) reject(new Error(`Error imprimiendo en ${name}: ${err2.message}`));
          else resolve();
        });
      });
    });
  });
}

const server = http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }

  if (req.method === "GET" && req.url === "/ping") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  // ── Endpoint de prueba: GET /test?dest=IP_O_NOMBRE ────────────────
  // Ejemplo: http://localhost:3001/test?dest=192.168.1.100
  if (req.method === "GET" && req.url.startsWith("/test")) {
    const dest = new URL("http://localhost" + req.url).searchParams.get("dest") || "";
    const ESC = "\x1B", GS = "\x1D";
    const testStr = ESC + "@" +                          // init
      ESC + "a\x01" +                                    // center
      ESC + "E\x01" + "PRUEBA DE IMPRESION\n" + ESC + "E\x00" +
      ESC + "a\x00" +                                    // left
      "--------------------------------\n" +
      "Si ves esto, la impresora funciona\n" +
      "--------------------------------\n" +
      "\n\n\n\n\n" + GS + "V\x41\x00";                  // cut

    const buffer = Buffer.from(testStr, "binary");
    const esIP = /^\d{1,3}(\.\d{1,3}){3}$/.test(dest.trim());

    const fn = esIP ? printToIP(dest.trim(), buffer) : printToWindows(dest.trim(), buffer);
    fn.then(() => {
      console.log(`[TEST] Enviado a ${dest}`);
      res.writeHead(200); res.end("OK - prueba enviada a " + dest);
    }).catch(e => {
      console.error(`[TEST ERROR]`, e.message);
      res.writeHead(500); res.end("ERROR: " + e.message);
    });
    return;
  }

  if (req.method === "POST" && req.url === "/print") {
    let body = "";
    req.on("data", chunk => (body += chunk));
    req.on("end", async () => {
      try {
        const { ip, name, data } = JSON.parse(body);
        const buffer = Buffer.from(data, "base64");
        console.log(`[PRINT] Recibido ${buffer.length} bytes para ${ip || name}`);

        if (ip) {
          await printToIP(ip, buffer);
          console.log(`[OK] Impreso en ${ip}`);
        } else if (name) {
          await printToWindows(name, buffer);
          console.log(`[OK] Impreso en ${name}`);
        } else {
          throw new Error("Se requiere ip o name");
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        console.error("[ERROR]", e.message);
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end();
});

server.listen(PORT, "127.0.0.1", () => {
  console.log("===========================================");
  console.log("  Roses Burgers - Servidor de Impresion");
  console.log(`  Corriendo en http://localhost:${PORT}`);
  console.log("  No cierres esta ventana mientras trabajas");
  console.log("===========================================");
});
